using DAL;
using DAL.Main;
using DAL.Repos;
using Domain.Interfaces;
using Domain.Main;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();


//DBContext
builder.Services.AddDbContext<AppDBContext>(options =>
        options.UseSqlServer(
            @"Data Source=xxxxxxxxxxxx;Initial Catalog=xxxxxxxxxxxx;User ID=xxx;Password=xxxxxxxxxxxxxxxxx"
        ));


#region Repositories
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
builder.Services.AddScoped(typeof(IGenericRepo<>), typeof(GenericRepo<>));

//builder.Services.AddTransient<IRepo, Repo>();
#endregion




// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
