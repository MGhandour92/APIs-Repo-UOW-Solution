﻿using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {

        }
    }
}
